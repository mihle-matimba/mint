package com.algohive.mint.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
