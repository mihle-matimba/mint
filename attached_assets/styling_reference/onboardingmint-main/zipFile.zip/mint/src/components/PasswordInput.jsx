import TextInput from './TextInput.jsx';

const PasswordInput = (props) => <TextInput type="password" {...props} />;

export default PasswordInput;
